Red bean
